﻿using System;
using System.Collections;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace ChattingServer
{
    delegate void SetTextDelegate(string s);

    public partial class Server : Form
    {
        TcpListener chatServer;
        ArrayList clientSocketArray = new ArrayList();
        string chatHistoryFile = "chat_history.txt";

        public Server()
        {
            InitializeComponent();
        }

        private void Server_Load(object sender, EventArgs e)
        {
            btnStart.Text = "Start Server";
            lblMsg.Text = "Server Stopped";
            lblMsg.Tag = "Stop";
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if ((string)lblMsg.Tag == "Stop")
            {
                StartServer();
            }
            else
            {
                StopServer();
            }
        }

        private void StartServer()
        {
            chatServer = new TcpListener(IPAddress.Parse("127.0.0.1"), 7777);
            chatServer.Start();

            LoadChatHistory(); // 이전에 저장된 채팅 내용을 로드

            lblMsg.Text = "Server Started";
            lblMsg.Tag = "Start";
            btnStart.Text = "Stop Server";

            Thread waitThread = new Thread(new ThreadStart(AcceptClient));
            waitThread.Start();
        }

        private void StopServer()
        {
            chatServer.Stop();
            foreach (Socket socket in clientSocketArray)
            {
                socket.Close();
            }
            clientSocketArray.Clear();

            lblMsg.Text = "Server Stopped";
            lblMsg.Tag = "Stop";
            btnStart.Text = "Start Server";
        }

        private void AcceptClient()
        {
            while (true)
            {
                try
                {
                    Socket socketClient = chatServer.AcceptSocket();
                    Thread clientThread = new Thread(() => HandleClient(socketClient));
                    clientThread.Start();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error accepting client connection: " + ex.Message);
                }
            }
        }

        private void HandleClient(Socket socketClient)
        {
            try
            {
                clientSocketArray.Add(socketClient);

                NetworkStream netStream = new NetworkStream(socketClient);
                StreamReader reader = new StreamReader(netStream);

                // 클라이언트에게 이전 채팅 내용 전송
                SendChatHistory(socketClient);

                while (true)
                {
                    string message = reader.ReadLine();
                    if (message != null)
                    {
                        SetText(message + "\r\n");
                        Broadcast(message);
                        SaveChatHistory(message); // 채팅 내용을 파일에 저장
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error handling client communication: " + ex.Message);
            }
            finally
            {
                socketClient.Close();
                clientSocketArray.Remove(socketClient);
            }
        }

        private void Broadcast(string message)
        {
            foreach (Socket socket in clientSocketArray)
            {
                try
                {
                    NetworkStream netStream = new NetworkStream(socket);
                    StreamWriter writer = new StreamWriter(netStream, Encoding.UTF8);
                    writer.WriteLine(message);
                    writer.Flush();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error broadcasting message to client: " + ex.Message);
                }
            }
        }

        private void SetText(string text)
        {
            if (txtChatMsg.InvokeRequired)
            {
                SetTextDelegate d = new SetTextDelegate(SetText);
                this.Invoke(d, new object[] { text });
            }
            else
            {
                this.txtChatMsg.AppendText(text);
            }
        }

        private void SaveChatHistory(string message)
        {
            try
            {
                using (StreamWriter writer = File.AppendText(chatHistoryFile))
                {
                    writer.WriteLine(message);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving chat history: " + ex.Message);
            }
        }

        private void LoadChatHistory()
        {
            try
            {
                if (File.Exists(chatHistoryFile))
                {
                    using (StreamReader reader = new StreamReader(chatHistoryFile))
                    {
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {
                            SetText(line + "\r\n");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading chat history: " + ex.Message);
            }
        }

        private void SendChatHistory(Socket socketClient)
        {
            try
            {
                if (File.Exists(chatHistoryFile))
                {
                    using (StreamReader reader = new StreamReader(chatHistoryFile))
                    {
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {
                            NetworkStream netStream = new NetworkStream(socketClient);
                            StreamWriter writer = new StreamWriter(netStream, Encoding.UTF8);
                            writer.WriteLine(line);
                            writer.Flush();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error sending chat history to client: " + ex.Message);
            }
        }
    }
}
