﻿using System.IO;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace ChattingClient
{
    public partial class Form1 : Form
    {
        private TcpClient tcpClient = null;
        private NetworkStream networkStream = null;
        private ChatHandler chatHandler = new ChatHandler();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            if (btnConnect.Text == "입장")
            {
                // 사용자 이름을 입력했는지 확인
                if (string.IsNullOrEmpty(txtName.Text))
                {
                    MessageBox.Show("사용자 이름을 입력하세요.", "입장 오류");
                    return;
                }

                try
                {
                    ConnectToServer();
                    StartChatThread();
                    SendMessage("<" + txtName.Text + "> 님이 입장했습니다.", true);
                    btnConnect.Text = "나가기";
                }
                catch (Exception ex)
                {
                    HandleConnectionError(ex);
                }
            }
            else
            {
                SendMessage("<" + txtName.Text + "> 님이 퇴장했습니다.", false);
                DisconnectFromServer();
            }
        }
        public class ChatClient
        {
            private MySqlConnection connection;
            private string server;
            private string database;
            private string uid;
            private string password;

            public ChatClient()
            {
                Initialize();
            }

            private void Initialize()
            {
                server = "localhost";
                database = "chat_db";
                uid = "username";
                password = "password";
                string connectionString = $"SERVER={server};DATABASE={database};UID={uid};PASSWORD={password};";

                connection = new MySqlConnection(connectionString);
            }

            public void SaveMessage(string message)
            {
                string query = $"INSERT INTO chat_messages (message) VALUES ('{message}');";
                ExecuteQuery(query);
            }

            public string[] GetChatHistory()
            {
                string query = "SELECT message FROM chat_messages;";
                return ExecuteQuery(query);
            }

            private string[] ExecuteQuery(string query)
            {
                try
                {
                    connection.Open();
                    MySqlCommand cmd = new MySqlCommand(query, connection);
                    MySqlDataReader dataReader = cmd.ExecuteReader();

                    var messages = new List<string>();
                    while (dataReader.Read())
                    {
                        messages.Add(dataReader["message"].ToString());
                    }

                    dataReader.Close();
                    connection.Close();

                    return messages.ToArray();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                    return new string[0];
                }
            }
        }
        private void ConnectToServer()
        {
            tcpClient = new TcpClient();
            tcpClient.Connect(IPAddress.Parse("127.0.0.1"), 7777);
            networkStream = tcpClient.GetStream();
            chatHandler.Setup(this, networkStream, txtChatMsg);
        }

        private void StartChatThread()
        {
            Thread chatThread = new Thread(new ThreadStart(chatHandler.ChatProcess));
            chatThread.Start();
        }

        private void DisconnectFromServer()
        {
            chatHandler.ChatClose();
            networkStream.Close();
            tcpClient.Close();
            btnConnect.Text = "입장";
        }

        private void SendMessage(string message, bool showMessage)
        {
            try
            {
                string dataToSend = $"[{DateTime.Now.ToString("HH:mm:ss")}] {message}\r\n";
                byte[] data = Encoding.UTF8.GetBytes(dataToSend);
                networkStream.Write(data, 0, data.Length);
            }
            catch (Exception ex)
            {
                if (showMessage)
                {
                    MessageBox.Show("서버 오류: " + ex.Message, "Client");
                }
                btnConnect.Text = "입장";
            }
        }

        public void SetText(string text)
        {
            if (txtChatMsg.InvokeRequired)
            {
                txtChatMsg.Invoke((MethodInvoker)delegate { txtChatMsg.AppendText(text); });
            }
            else
            {
                txtChatMsg.AppendText(text);
            }
        }

        private void HandleConnectionError(Exception ex)
        {
            MessageBox.Show("오류 발생: " + ex.Message, "클라이언트 오류");
            DisconnectFromServer();
        }

        private void txtMsg_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13 && btnConnect.Text == "나가기")
            {
                SendMessage("<" + txtName.Text + ">" + txtMsg.Text, true);
                txtMsg.Text = "";
                e.Handled = true;
            }
        }
    }

    public class ChatHandler
    {
        private TextBox chatTextBox;
        private NetworkStream networkStream;
        private StreamReader streamReader;
        private Form1 form;

        public void Setup(Form1 form, NetworkStream networkStream, TextBox chatTextBox)
        {
            this.form = form;
            this.networkStream = networkStream;
            this.chatTextBox = chatTextBox;
            this.streamReader = new StreamReader(networkStream);
        }

        public void ChatClose()
        {
            networkStream.Close();
            streamReader.Close();
        }

        public void ChatProcess()
        {
            try
            {
                while (true)
                {
                    string receivedMessage = streamReader.ReadLine();

                    if (!string.IsNullOrEmpty(receivedMessage))
                    {
                        form.SetText(receivedMessage + "\r\n");
                    }
                }
            }
            catch (IOException ex)
            {
                // 서버와의 연결이 끊어졌을 때 처리
                MessageBox.Show("서버 연결이 끊어졌습니다: " + ex.Message, "클라이언트 오류");
                form.Invoke((MethodInvoker)delegate { form.btnConnect.Text = "입장"; });
            }
        }
    }
}
